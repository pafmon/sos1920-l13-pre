<script>
	import MyGraph from "./MyGraph.svelte";
</script>
<main>
	<h1>My Graph</h1>
	<MyGraph/>
</main>
