const express = require("express");

var app = express();
var port = process.env.port || 2222;

app.get("/data", (req,res) =>{
    var data = [10,2,3,4,5,6,7];
    res.send(data);
});

app.use("/",express.static("public"));

app.listen(port,()=>{
    console.log("Server ready at port "+port);
});
